# ctags Code Mapping Toolkit

Complete toolkit for mapping source code variables, functions, and structure across Python, C#, JavaScript, and 40+ other languages.

## Files Included

### Documentation
- **CTAGS_SETUP.md** - Complete installation and configuration guide
- **CTAGS_QUICK_REFERENCE.md** - Quick examples and common patterns
- **CTAGS_INTEGRATION_EXAMPLE.md** - Full workflow with ClickUp, CI/CD, automation

### Tools
- **ctags_parser.py** - Python utility for parsing ctags JSON output
- **CtagsMapper.psm1** - PowerShell module for Windows/C# workflows

## Quick Start

### 1. Install ctags (with JSON support)

```bash
# macOS
brew install libjansson universal-ctags

# Ubuntu/Debian
sudo apt-get install libjansson-dev universal-ctags

# Fedora/RHEL
sudo dnf install jansson-devel universal-ctags
```

### 2. Generate Code Map

```bash
ctags --output-format=json -R . > tags.json
```

### 3. Parse and Analyze

**Python:**
```bash
python3 ctags_parser.py tags.json show src/module.py
python3 ctags_parser.py tags.json filter Python class
```

**PowerShell:**
```powershell
Import-Module .\CtagsMapper.psm1
$parser = New-CtagsParser 'tags.json'
Show-SymbolTree -Parser $parser -FilePath 'src/Service.cs'
```

## What It Does

- **Maps all symbols** - Functions, classes, variables, methods across 40+ languages
- **Line numbers** - Knows start/end lines for every symbol
- **Scope tracking** - Understands class hierarchy and nested functions
- **Cross-language** - Single tool for Python, C#, JavaScript, Java, Go, Rust, etc.
- **Fast** - Scales to large codebases instantly
- **JSON output** - Integrates with automation and tooling

## Use Cases

### 1. Code Documentation
```bash
python3 ctags_parser.py tags.json markdown src/services/user.py > docs/UserService.md
```

### 2. ClickUp Integration
Automatically create tasks documenting code structure and changes

### 3. CI/CD Automation
Generate code metrics and architecture diagrams in GitHub Actions

### 4. Code Review Tools
Map dependencies and scope relationships for better reviews

### 5. Refactoring Analysis
Find all references and understand impact of changes

### 6. Architecture Tracking
Monitor code growth and complexity metrics over time

## Example Output

```json
{
  "_type": "tag",
  "name": "authenticate",
  "path": "src/auth/service.py",
  "kind": "function",
  "language": "Python",
  "line": 42,
  "end": 67,
  "scope": "AuthService",
  "scopeKind": "class"
}
```

## Features

✅ **40+ Language Support** - Python, C#, JavaScript, Java, Go, Rust, C++, PHP, Ruby, etc.
✅ **Hierarchical Structure** - Classes contain methods, scopes properly nested
✅ **Line Range Tracking** - Know exactly where each symbol starts and ends
✅ **Fast Processing** - Handles large codebases in seconds
✅ **Zero Maintenance** - No configuration needed, works out of the box
✅ **JSON Output** - Machine-readable, easy to parse and automate
✅ **Cross-Platform** - Works on macOS, Linux, Windows with PowerShell
✅ **CLI Tools** - Python script and PowerShell module included
✅ **CI/CD Ready** - GitHub Actions examples provided

## Language Support

### Primary
Python, C#, JavaScript/TypeScript, Java, C++, C, PHP, Ruby, Go, Rust

### Also Supported
Kotlin, Swift, Objective-C, Scala, Haskell, Clojure, Lua, Perl, Bash, PowerShell, YAML, Toml, JSON, XML, HTML, CSS, and 60+ others

See full list:
```bash
ctags --list-languages
```

## File Structure

```
├── CTAGS_SETUP.md                          # Installation and setup guide
├── CTAGS_QUICK_REFERENCE.md               # Quick examples and patterns
├── CTAGS_INTEGRATION_EXAMPLE.md           # Full workflow example
├── ctags_parser.py                         # Python CLI tool
├── CtagsMapper.psm1                        # PowerShell module
└── README.md                               # This file
```

## Key Concepts

### Tags
Each "tag" represents a symbol in code (function, class, variable, etc.). Contains:
- Name (the symbol)
- Path (file location)
- Kind (function, class, variable, etc.)
- Line/End (starting and ending lines)
- Scope (parent class/function)
- Language

### Code Map
A structured view of code in a file showing:
- Classes and their methods
- Top-level functions
- Module variables
- Hierarchical relationships

### JSON Lines Format
Each line is a complete JSON object representing one tag:
```
{"_type": "tag", "name": "foo", "path": "file.py", ...}
{"_type": "tag", "name": "bar", "path": "file.py", ...}
```

## Integration Examples

### With ClickUp
See CTAGS_INTEGRATION_EXAMPLE.md for complete example of syncing code structure to ClickUp tasks

### With GitHub Actions
Automatically generate code maps and documentation on every push

### With Your CLI Tools
Integrate with existing automation and task management workflows

## Performance Notes

- **Fast for most projects** - Generates maps for 10,000+ files in seconds
- **Exclude directories** - Use `--exclude=node_modules,bin,obj` for speed
- **Limit languages** - Use `--languages=Python,C#` when you don't need all languages
- **JSON slightly slower** - JSON output is slower than default format, but still very fast

## Troubleshooting

### "ctags: unknown output format name supplied for 'output-format=json'"

libjansson not linked. Rebuild:

```bash
# macOS
brew uninstall universal-ctags
brew install universal-ctags  # Should now have jansson support

# Linux from source
git clone https://github.com/universal-ctags/ctags.git
cd ctags && ./autogen.sh && ./configure --enable-json && make && sudo make install
```

### Missing symbols

- Check language is supported: `ctags --list-languages`
- Verify file extension matches language
- Try without `--languages=` filter to see all

### Line numbers don't match

- Ensure you're using `--fields=+e` to get end line numbers
- Line numbers are 1-indexed
- Some async/multiline constructs may have unexpected ranges

## Learning Resources

- Official Docs: https://docs.ctags.io/
- JSON Output Spec: https://docs.ctags.io/en/latest/man/ctags-json-output.5.html
- GitHub: https://github.com/universal-ctags/ctags

## License

ctags is GPL-2.0 licensed.
These tools are provided as examples for integrating with ctags.

## Support

For ctags issues: https://github.com/universal-ctags/ctags/issues
For these tools: Refer to the documentation files included

---

**Ready to start?** Begin with CTAGS_QUICK_REFERENCE.md for basic usage, then CTAGS_INTEGRATION_EXAMPLE.md for advanced workflows.
